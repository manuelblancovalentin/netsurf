# Editorial / evidence register — NetSuRF first paper

**Chosen journal:** ACM Transactions on Embedded Computing Systems (TECS); retain current ACM `acmart` manuscript style. No alternative journal is better supported without a new venue assessment. The journal code `TECS` is confirmed by the ACM class.

**Chosen working title:** *Beyond Static Bit Criticality: Conditional Fault Susceptibility and Protection Limits in Quantized Neural Networks*.

**Claim hierarchy:**

- **Mathematically established:** Boolean fault set-function, Mӧbius expansion, exact conditional marginal protection benefit, p-biased Fourier identities.
- **Experimentally observed:** 320-bit stratified isolated-fault studies and static protection sweeps on ResNet-8, DS-CNN, and ToyCar, with nonuniversal relative policies and ToyCar loss/AUC misalignment.
- **NOT established:** direct measured second-/higher-order interactions as the cause of differences; population-wide ranking superiority; exact optimal full-network protection; global NP-hardness theorem; implemented guided conditional MC, trained spectral predictor, physical ECC/ABFT/TMR overhead, radiation-calibrated SEU effects.

**Authoritative local evidence:** `m92_resnet8_static_test1000_v1_results.zip`, `m93_kws_static_ber_sweep1000_v1_results.zip`, `m93_toycar_static_ber_pilot64_parallel_repair_v1_results.zip`, and `M93_CROSS_BENCHMARK_MECHANISMS.md`; original manifest hashes and finalized paths on Kona supersede derived analyses. Interpret saved p-value corrections at their documented multiplicity-family scope only.

**Direct next experiment:** exact isolated-vs-conditional marginal damage for the same bits at BER 1e-4, 1e-3, 1e-2, common backgrounds and held-out validation; plus restricted combinatorial optimum with exact isolated oracle. If not available by Nov 5, do not claim interaction-caused ranking failure as measured; downgrade draft to characterization + formulation.

**Four-paper plan:** (1) conditional susceptibility characterization / TECS; (2) guided conditional MC mask search and comparisons with unguided, annealed, greedy and RL alternatives; (3) spectral/discrete fault-response theory (if demonstrable independent predictive contribution); (4) hardware implementation and fair ECC/TMR/ABFT/Ranger comparisons.

**New references checked against publication landing pages:** Catalán/Flich/Hernández 2025 (online 2024), Su et al. 2025, Leveugle et al. 2025, Zhang et al. 2025, Duong et al. Oct 2026 arXiv preprint, Bacellar et al. 2026 arXiv preprint, Yu et al. 2023 ICML, O'Donnell 2014 Cambridge, FlatENN (arXiv:2301.00675), and BARE-AI (arXiv:2610.08739). Existing 16 original records preserved from the uploaded placeholder and not fully re-audited here.

**Important mathematical warning:** exact swap identity in the protection-allocation section holds only for the same background distribution excluding exchanged bits; pairwise Hessian of a smooth surrogate is not the exact discrete Hessian. The first-order optimum claim needs additive and nonnegative benefits for fixed-size top-B selection (otherwise at-most-B can choose fewer). Spectral variance proportion does not prove policy regret.
