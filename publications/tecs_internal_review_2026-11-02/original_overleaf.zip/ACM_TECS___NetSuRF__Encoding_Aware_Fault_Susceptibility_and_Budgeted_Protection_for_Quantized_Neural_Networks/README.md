# NetSuRF — ACM TECS research draft (29 October 2026)

Main entry: **main.tex**. Upload the *contents of this ZIP* into a new or existing Overleaf project and select `main.tex` as the root document. The existing ACM `acmart` review manuscript format and journal code `TECS` have been preserved. This is a **research draft**, not a submission-ready final manuscript.

## What's inside

- `sections/01`–`09`: full prose draft, rigorous mathematical definitions and preliminary published-proof points, with explicit unfinished experimental sections.
- `sections/10_mathematical_appendix.tex`: exact protection marginal and p-biased Fourier framework, **presented as mathematical background / future direction, not as an executed spectral contribution**.
- `references.bib`: original bibliography retained plus ten verified research references, all cited within text.
- `DRAFT_DECISIONS_AND_EVIDENCE.md`: source/claim verification, necessary experiment gates, author checklist and related publication plan.

## Immediate editorial checklist

1. Confirm coauthors with supervisor; only one existing named author is retained. Do not publish as single-author without discussing contribution/permission.
2. Execute direct conditional-bit-versus-background tests and small restricted-domain optimum before making the strong mechanistic interaction claim. Until then the paper only establishes a precise formulation and exploratory heterogeneous static-mask outcomes.
3. Add final methods, dataset exact split IDs, paired-test family decisions, effect sizes and checksum-backed figures generated from finalized evidence.
4. Add validated Hessian / FKeras and comparative statics if required by target reviewers. Do not equate diagonal Hessian approximation with exact discrete pair interaction.
5. Verify all existing bibliography fields/DOIs in the original bibliography as well as the newly added verified items, and verify ACM TECS submission instructions on submission day.
6. Keep final labels and fault fields independent of candidate/optimization selection. Distinguish ideal event suppression from real hardware hardening.

Draft timestamp and claims: October 29, 2026 (America/Chicago). Planned first manuscript draft: **November 12, 2026**.
